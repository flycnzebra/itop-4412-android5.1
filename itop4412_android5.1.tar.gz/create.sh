#!/bin/bash

PLATFORM_DEVICE=itop4412

OUTDIR=out/target/product/itop4412
HOSTBIN=out/host/linux-x86/bin

source build/envsetup.sh

lunch full_${PLATFORM_DEVICE}-eng

make -j4

${HOSTBIN}/mkbootfs ${OUTDIR}/root | ${HOSTBIN}/minigzip > ${OUTDIR}/ramdisk.img

mkimage -A arm -O linux -T ramdisk -C none -a 0x40800000 -n "ramdisk" -d ${OUTDIR}/ramdisk.img ${OUTDIR}/ramdisk-uboot.img
